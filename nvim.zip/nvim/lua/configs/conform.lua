return {
  formatters_by_ft = {
    go = { "goimports", "gofmt" },
    rust = { "rustfmt" },
  }
}
