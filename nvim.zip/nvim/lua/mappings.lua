require "nvchad.mappings"

local map = vim.keymap.set

map("n", "<leader>,", "<cmd>qa<CR>", { desc = "quit all" })

map("n", "^", "0", { desc = "move to the beginning of the line" })
map("n", "0", "^", { desc = "move to the first non-space charactor of the line" })

-- nvimtree
map("n", "<leader>n", "<cmd>NvimTreeToggle<CR>", { desc = "nvimtree toggle window" })

-- telescope
map("n", "<leader>fg", "<cmd>Telescope live_grep<CR>", { desc = "telescope live grep" })

-- git blame
map("n", "<leader>i", "<cmd>BlameToggle<CR>", { desc = "toggle git blame" })

-- todo
map("n", "<leader>td", "<cmd>TodoQuickFix keywords=TODO,FIX<CR>", { desc = "todo list" })
